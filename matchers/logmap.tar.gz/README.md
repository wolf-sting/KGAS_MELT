# Logmap

This directory exists to set up a docker image which can run the [Logmap CLI](https://github.com/ernestojimenezruiz/logmap-matcher).

It also contains scripts and config for running an SSH server, such that the CLI can be accessed externally.