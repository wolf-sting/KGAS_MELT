#! /bin/bash

../push_to_acr.sh